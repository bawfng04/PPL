# Generated from /home/don/Code/Course/PPL/Template_BTL_PPL/main/VoTien.g4 by ANTLR 4.13.1
from antlr4 import *
if "." in __name__:
    from .VoTienParser import VoTienParser
else:
    from VoTienParser import VoTienParser

# This class defines a complete listener for a parse tree produced by VoTienParser.
class VoTienListener(ParseTreeListener):

    # Enter a parse tree produced by VoTienParser#program.
    def enterProgram(self, ctx:VoTienParser.ProgramContext):
        pass

    # Exit a parse tree produced by VoTienParser#program.
    def exitProgram(self, ctx:VoTienParser.ProgramContext):
        pass


    # Enter a parse tree produced by VoTienParser#statement.
    def enterStatement(self, ctx:VoTienParser.StatementContext):
        pass

    # Exit a parse tree produced by VoTienParser#statement.
    def exitStatement(self, ctx:VoTienParser.StatementContext):
        pass


    # Enter a parse tree produced by VoTienParser#declaration_statement.
    def enterDeclaration_statement(self, ctx:VoTienParser.Declaration_statementContext):
        pass

    # Exit a parse tree produced by VoTienParser#declaration_statement.
    def exitDeclaration_statement(self, ctx:VoTienParser.Declaration_statementContext):
        pass


    # Enter a parse tree produced by VoTienParser#call_statement.
    def enterCall_statement(self, ctx:VoTienParser.Call_statementContext):
        pass

    # Exit a parse tree produced by VoTienParser#call_statement.
    def exitCall_statement(self, ctx:VoTienParser.Call_statementContext):
        pass


    # Enter a parse tree produced by VoTienParser#expression.
    def enterExpression(self, ctx:VoTienParser.ExpressionContext):
        pass

    # Exit a parse tree produced by VoTienParser#expression.
    def exitExpression(self, ctx:VoTienParser.ExpressionContext):
        pass


    # Enter a parse tree produced by VoTienParser#expression1.
    def enterExpression1(self, ctx:VoTienParser.Expression1Context):
        pass

    # Exit a parse tree produced by VoTienParser#expression1.
    def exitExpression1(self, ctx:VoTienParser.Expression1Context):
        pass



del VoTienParser